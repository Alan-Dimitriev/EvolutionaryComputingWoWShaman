CISC 851: Final Project
Alan Dimitriev - 20062431

Executing the code:
To run the main evolutionary algorithm the python file can be ran as is. 
All implementation is included in the main() function.
Number of unique trials (n), number of iterations (vmax), size of population (pop_size) and length of rotations (individual length) can all be customized
Please note that the program does take more time for populations mapping a longer period of time.
To run the greedy algorithm used for comparison uncomment the specified lines.
Rest of the implementation should be rather straightwforward as the code is well documented.


Note: The output of my algorithm is a set of rather long rotations and their associated times making it really difficult to include them directly
into the paper itself. I have included my results in outputs.txt and based my conclusions and analysis of my model off of those trials.